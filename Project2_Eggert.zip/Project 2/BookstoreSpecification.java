public interface BookstoreSpecification {

    public void restockProduct(int x, int y);
      

    public double inventoryValue();
        






} // end bookstore specification class